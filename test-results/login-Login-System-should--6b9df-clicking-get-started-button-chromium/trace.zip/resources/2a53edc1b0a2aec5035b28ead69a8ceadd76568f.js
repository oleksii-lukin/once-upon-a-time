(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_aaf1d8da._.js",
  "static/chunks/e12d4_next_dist_compiled_react-dom_00210425._.js",
  "static/chunks/e12d4_next_dist_compiled_react-server-dom-turbopack_b0465c44._.js",
  "static/chunks/e12d4_next_dist_compiled_next-devtools_index_9373d827.js",
  "static/chunks/e12d4_next_dist_compiled_426b347f._.js",
  "static/chunks/e12d4_next_dist_client_4982f2c2._.js",
  "static/chunks/e12d4_next_dist_2f764ec6._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
