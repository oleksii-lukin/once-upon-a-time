(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/.pnpm/@clerk+nextjs@6.36.7_next@16.1.1_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwrigh_fe0484efd858e77816e9bf3645992c3f/node_modules/@clerk/nextjs/dist/esm/app-router/client/keyless-creator-reader.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/1ca16_@clerk_nextjs_dist_esm_app-router_0c70788b._.js",
  "static/chunks/1ca16_@clerk_nextjs_dist_esm_app-router_client_keyless-creator-reader_da3a5c20.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/@clerk+nextjs@6.36.7_next@16.1.1_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwrigh_fe0484efd858e77816e9bf3645992c3f/node_modules/@clerk/nextjs/dist/esm/app-router/client/keyless-creator-reader.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/.pnpm/@clerk+nextjs@6.36.7_next@16.1.1_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwrigh_fe0484efd858e77816e9bf3645992c3f/node_modules/@clerk/nextjs/dist/esm/app-router/keyless-actions.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/1ca16_@clerk_nextjs_dist_esm_app-router_18aea14d._.js",
  "static/chunks/1ca16_@clerk_nextjs_dist_esm_app-router_keyless-actions_9b546af8.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/.pnpm/@clerk+nextjs@6.36.7_next@16.1.1_@babel+core@7.28.6_@opentelemetry+api@1.9.0_@playwrigh_fe0484efd858e77816e9bf3645992c3f/node_modules/@clerk/nextjs/dist/esm/app-router/keyless-actions.js [app-client] (ecmascript)");
    });
});
}),
"[project]/public/locales/en/common.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/public_locales_en_common_json_13cd6fb6._.js",
  "static/chunks/public_locales_en_common_json_474c5e35._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/en/common.json (json)");
    });
});
}),
"[project]/public/locales/ru/common.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/public_locales_ru_common_json_2ea1112f._.js",
  "static/chunks/public_locales_ru_common_json_474c5e35._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ru/common.json (json)");
    });
});
}),
"[project]/public/locales/ua/common.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/public_locales_ua_common_json_2c9387d9._.js",
  "static/chunks/public_locales_ua_common_json_474c5e35._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/public/locales/ua/common.json (json)");
    });
});
}),
"[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/_6d0139c3._.js",
  "static/chunks/components_theme_ThemeToggle_tsx_56e71449._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/components/theme/ThemeToggle.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);