(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__a8773abd._.css",
  "static/chunks/_10cb6185._.js",
  "static/chunks/70e5e_@clerk_shared_dist_runtime_23f6e84a._.js",
  "static/chunks/d8277_swr_dist_3458586b._.js",
  "static/chunks/11351_@clerk_clerk-react_dist_4c5d9eda._.js",
  "static/chunks/1ca16_@clerk_nextjs_dist_esm_3efd621e._.js",
  "static/chunks/e12d4_next_e7986cb6._.js",
  "static/chunks/ca680_react-i18next_dist_es_e4b179de._.js",
  "static/chunks/node_modules__pnpm_63d87373._.js",
  "static/chunks/_c4024d4d._.js"
],
    source: "dynamic"
});
